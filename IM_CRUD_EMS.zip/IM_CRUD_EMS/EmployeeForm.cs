﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace IM_CRUD_EMS
{
    public partial class EmployeeForm : Form
    {
        private int selectedId = -1;
        public EmployeeForm()
        {
            InitializeComponent();
            LoadEmployees();
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {

        }
        private void LoadEmployees()
        {
            dgvEmployees.DataSource = DbHelper.GetEmployees();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string salaryText = txtSalary.Text.Replace(",", "").Trim();

            if (!decimal.TryParse(salaryText, out decimal salary))
            {
                MessageBox.Show("Please enter a valid numeric salary.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "INSERT INTO employees (first_name, last_name, position, department, salary, date_hired) " +
                           "VALUES (@fn, @ln, @pos, @dep, @sal, @date)";

            using (MySqlConnection conn = DbHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@fn", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@ln", txtLastName.Text);
                cmd.Parameters.AddWithValue("@pos", txtPosition.Text);
                cmd.Parameters.AddWithValue("@dep", txtDepartment.Text);
                cmd.Parameters.AddWithValue("@sal", salary);
                cmd.Parameters.AddWithValue("@date", dtpDateHired.Value);
                cmd.ExecuteNonQuery();
            }

            LoadEmployees();
            ClearInputs();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvEmployees_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedId = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells["id"].Value);
                txtFirstName.Text = dgvEmployees.Rows[e.RowIndex].Cells["first_name"].Value.ToString();
                txtLastName.Text = dgvEmployees.Rows[e.RowIndex].Cells["last_name"].Value.ToString();
                txtPosition.Text = dgvEmployees.Rows[e.RowIndex].Cells["position"].Value.ToString();
                txtDepartment.Text = dgvEmployees.Rows[e.RowIndex].Cells["department"].Value.ToString();
                txtSalary.Text = dgvEmployees.Rows[e.RowIndex].Cells["salary"].Value.ToString();
                dtpDateHired.Value = Convert.ToDateTime(dgvEmployees.Rows[e.RowIndex].Cells["date_hired"].Value);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) return;

            string query = "UPDATE employees SET first_name=@fn, last_name=@ln, position=@pos, department=@dep, salary=@sal, date_hired=@date WHERE id=@id";

            using (MySqlConnection conn = DbHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@fn", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@ln", txtLastName.Text);
                cmd.Parameters.AddWithValue("@pos", txtPosition.Text);
                cmd.Parameters.AddWithValue("@dep", txtDepartment.Text);
                cmd.Parameters.AddWithValue("@sal", txtSalary.Text);
                cmd.Parameters.AddWithValue("@date", dtpDateHired.Value);
                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
            }

            LoadEmployees();
            ClearInputs();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) return;

            using (MySqlConnection conn = DbHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("DELETE FROM employees WHERE id=@id", conn);
                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
            }

            LoadEmployees();
            ClearInputs();
        }

        private void ClearInputs()
        {
            selectedId = -1;
            txtFirstName.Clear();
            txtLastName.Clear();
            txtPosition.Clear();
            txtDepartment.Clear();
            txtSalary.Clear();
            dtpDateHired.Value = DateTime.Now;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            DashboardForm dashboard = new DashboardForm();
            dashboard.Show();
        }

        private void txtFirstName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;  
                txtLastName.Focus();        
            }
        }

        private void txtLastName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtPosition.Focus();
            }
        }

        private void txtPosition_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtDepartment.Focus();
            }
        }

        private void txtDepartment_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtSalary.Focus();
            }
        }

        private void txtSalary_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
