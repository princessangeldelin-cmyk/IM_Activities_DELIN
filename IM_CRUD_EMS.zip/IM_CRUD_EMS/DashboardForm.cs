﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace IM_CRUD_EMS
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
            LoadDashboardStats();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {

        }

        private void LoadDashboardStats()
        {
            using (MySqlConnection conn = DbHelper.GetConnection())
            {
                conn.Open();

                MySqlCommand cmdTotal = new MySqlCommand("SELECT COUNT(*) FROM employees", conn);
                lblTotalEmployees.Text = "Total Employees: " + cmdTotal.ExecuteScalar().ToString();

                MySqlCommand cmdAvg = new MySqlCommand("SELECT ROUND(AVG(salary),2) FROM employees", conn);
                lblAvgSalary.Text = "Average Salary: ₱" + cmdAvg.ExecuteScalar().ToString();
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            EmployeeForm empForm = new EmployeeForm();
            empForm.ShowDialog();
            LoadDashboardStats();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 login = new Form1();
            login.ShowDialog();
            this.Close();
        }

        private void DashboardForm_KeyDown(object sender, KeyEventArgs e)
        {
            
        }
    }
}
